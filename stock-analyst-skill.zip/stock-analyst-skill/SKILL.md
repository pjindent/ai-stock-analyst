---
name: stock-analyst
description: Local-server stock analysis tool. Use this skill whenever the user wants to analyze stocks, get buy/sell recommendations, check technicals (RSI, MACD, moving averages), view fundamentals (P/E, EPS, PEG), or manage a stock watchlist. Triggers on: stock analysis, ticker lookup, buy/sell recommendation, market data, portfolio screening, technical analysis, yfinance, Finnhub.
---

# Stock Analyst Skill

Provides full stock market analysis using a local Python server (yfinance/Finnhub) for zero-token data fetching, with Claude providing only the AI recommendation (~300 tokens per ticker).

## Architecture

```
Claude Artifact (browser)
        │
        ▼ GET /batch?tickers=AAPL,NVDA   (0 tokens — direct HTTP)
Local Python Server (localhost:7823)
        │
        ├── yfinance (free, no key needed)  ← primary
        └── Finnhub  (optional fallback, set FINNHUB_KEY env var)
        │
        Returns: price, fundamentals, MA50/200, RSI, MACD, OBV, news
        │
        ▼ pre-built data passed to Claude
Claude API (Anthropic)
        │  max_tokens=400, NO web_search tool
        └── Returns: rating, entry, target, stop-loss, bull/bear case
```

**Token cost per ticker: ~300** (recommendation only — all data from local server)

## Setup Instructions

### 1. Install Python dependencies
```bash
pip install yfinance flask flask-cors requests
```

### 2. (Optional) Set Finnhub key for fallback
```bash
# Mac/Linux
export FINNHUB_KEY=your_key_here

# Windows
set FINNHUB_KEY=your_key_here
```

### 3. Start the server
```bash
python scripts/server.py
```

Server starts on **http://localhost:7823**

### 4. Verify it's running
```bash
curl http://localhost:7823/health
# → {"status":"ok","yfinance":true,"finnhub":false,...}
```

### 5. Load the artifact
Open `scripts/artifact.jsx` in Claude.ai — the green "Online" indicator confirms server connection.

## API Endpoints

| Endpoint | Description |
|---|---|
| `GET /health` | Server status, data source availability |
| `GET /stock/AAPL` | Full data for one ticker |
| `GET /batch?tickers=AAPL,NVDA,TSLA` | Up to 6 tickers in one call |

## Data Provided (0 tokens each)

- **Price**: current, change, open/high/low, volume, market cap
- **52-week**: high, low, % position
- **Valuation**: P/E, Forward P/E, PEG, P/B, P/S, EPS (trailing + forward), dividend yield, beta, ROE, revenue growth, gross margins
- **Technicals** (calculated from 1yr daily candles):
  - SMA 50 & 200 day
  - RSI (14-period)
  - MACD (12/26/9) with signal line and histogram
  - OBV trend (rising/falling/neutral)
  - Overall signal (bullish/bearish/neutral)
- **News**: up to 6 recent headlines via yfinance

## Claude's Role (~300 tokens per ticker)

Claude receives the pre-built data and outputs ONLY:
- Rating (STRONG BUY / BUY / HOLD / SELL / STRONG SELL)
- Entry price, 12-month price target, stop-loss
- Upside %, confidence level
- 2 bull case points, 2 bear case points
- 1-2 sentence summary
- Estimated Zacks rank (from EPS trend data)

No web_search tool is used — all data is already provided.

## Token Comparison

| Scenario | Old (web search) | New (local server) |
|---|---|---|
| 1 ticker full report | ~2,500 tokens | ~300 tokens |
| 5 tickers batch scan | ~10,000 tokens | ~1,500 tokens |
| Re-fetch same ticker | same cost | **0 tokens** (cached) |

## Troubleshooting

**"Server offline" shown in artifact**
- Run `python scripts/server.py` and wait for the startup banner
- Check firewall isn't blocking port 7823
- Try `curl http://localhost:7823/health` in terminal

**yfinance returns no data for a ticker**
- Some tickers use exchange suffixes: `RELIANCE.NS` (NSE), `VOD.L` (LSE)
- ETFs and indices are supported: `SPY`, `QQQ`, `^GSPC`

**Change the port**
```bash
PORT=8080 python scripts/server.py
```
Then update `const SERVER = "http://localhost:8080"` in artifact.jsx line 4.
